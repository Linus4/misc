# Installation

Extract these files into the `/csg/cfg` directory of your CSGO-server.

Fill in the fields marked with `FIXME` in `server.cfg`.

Restart CSGO-server.

# Usage

Open console and enter `rcon_password [yourpassword]` to log in.

Type `rcon cmds` for an overview of the commands.

You will need to record demos manually with `rcon tv_record [demoname (optional)]` and `rcon tv_stoprecord`.

Pausing the match is also done manually with `rcon mp_pause_match` and `rcon mp_unpause_match`. You should bind pause to a key.

To spectate one player: disable respawns, 2 join spectator, others join one team and type 'kill' .

# Commands

Available commands (rcon): 

* warmup (load warmup config [60.000$] and restart game)
* prac (load practice [cheats] config and restart game)
* knife (load kniferound config and restart game [need to swap teams manually])
* live (load 5v5 config and restart game)
* rr (restart game)
* swap (swap teams and restart game)
* respawns (toggles respawns on/off)
* cmds (shows commands)
